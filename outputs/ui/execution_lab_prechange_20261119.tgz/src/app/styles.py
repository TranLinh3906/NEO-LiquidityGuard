"""Scoped Streamlit shell derived from the supplied design tokens."""
from pathlib import Path

CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Nunito+Sans:wght@600;700;800;900&display=swap');
html,body,[class*="css"] {font-family:Inter,sans-serif;}
.stApp {background:linear-gradient(120deg,#EBDEF2,#F5EBF3);color:#30243C;}
[data-testid="stHeader"]{background:transparent;height:0;}
[data-testid="stToolbar"]{display:none;}
.stMainBlockContainer{max-width:1420px;padding:18px 20px 25px;margin:22px auto;background:radial-gradient(ellipse at 75% 0%,#755a7a60,transparent 60%),linear-gradient(120deg,#3E2F4F,#594361);border:1px solid #BDAFD1;border-radius:34px;box-shadow:0 22px 44px #3e2f4f44;min-height:970px;}
.stMainBlockContainer > div > [data-testid="stVerticalBlock"]{gap:10px;}
.stMainBlockContainer h1,.stMainBlockContainer h2,.stMainBlockContainer h3{font-family:'Nunito Sans',sans-serif;}
.lg-brand{font:900 20px 'Nunito Sans',sans-serif;color:white;display:flex;align-items:center;gap:5px;white-space:nowrap;}
.lg-brand img{width:43px;height:43px;object-fit:contain;}
.lg-greeting{color:#fff;font-size:11px;text-align:right;line-height:1.5;padding-top:5px;}
.lg-greeting small{color:#E6D9EA;font-size:10px;}
.lg-section-title{font:800 19px 'Nunito Sans',sans-serif;color:#30243C;margin-bottom:6px;}
.lg-eyebrow{font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#7e638f;font-weight:800;}
.lg-subtle{font-size:11px;color:#776883;line-height:1.5;}
.lg-pill{display:inline-block;background:#DCCFF0;color:#3E2F4F;padding:4px 9px;border-radius:999px;font-size:10px;font-weight:700;}
.lg-pill.demo{background:#F3C9DD;color:#5c305d;}
.lg-kpi{min-height:103px;padding:12px 10px;border-radius:23px;background:linear-gradient(145deg,#faf7fc,#dccff0);box-shadow:0 7px 18px #24192f22;border:1px solid #ffffff90;}
.lg-kpi.k1{background:linear-gradient(140deg,#faf7fc,#f3c9dd);}.lg-kpi.k2{background:linear-gradient(140deg,#faf7fc,#f2e6d7);}
.lg-kpi.k3{background:linear-gradient(140deg,#faf7fc,#f3c9dd);}.lg-kpi.k4{background:linear-gradient(140deg,#faf7fc,#dccff0);}
.lg-kpi.k5{background:linear-gradient(140deg,#faf7fc,#e3efde);}.lg-kpi.k6{background:linear-gradient(140deg,#faf7fc,#bdafd1);}
.lg-kpi-label{font-size:11px;font-weight:700;display:flex;align-items:center;gap:4px;white-space:nowrap;}
.lg-kpi-value{font:900 25px 'Nunito Sans',sans-serif;line-height:1.45;letter-spacing:-.8px;white-space:nowrap;}
.lg-kpi small{font-size:9px;color:#6e547d;}.lg-kpi svg{color:#9563C4;width:19px;height:19px;}
.lg-hero{height:268px;border-radius:26px;border:1px solid #ffffff50;position:relative;overflow:hidden;background:radial-gradient(ellipse at 60% 80%,#DCCFF0 0%,transparent 46%),linear-gradient(120deg,#715578,#BDAFD1);padding:26px 24px;color:white;box-shadow:0 12px 28px #24192f2a;}
.lg-hero-copy{position:relative;z-index:2;width:34%;}.lg-hero h1{font:900 33px 'Nunito Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:8px 0 10px;color:white;line-height:1.05;}.lg-hero p{font-size:13px;line-height:1.6;margin:0;color:#fff4ff;}
.lg-mascot{position:absolute;width:35%;height:100%;object-fit:contain;bottom:-5px;left:32%;filter:drop-shadow(0 9px 10px #3e2f4f33);animation:float 5s ease-in-out infinite;}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
@media(prefers-reduced-motion:reduce){.lg-mascot{animation:none}}
.lg-progress{position:absolute;right:18px;top:23px;width:29%;padding:15px;border:1px solid #ffffff80;border-radius:24px;background:#f7eaf4c9;color:#30243C;backdrop-filter:blur(6px);}
.lg-progress strong{font-size:12px;}.lg-progress-track{height:10px;border-radius:10px;background:#3e2f4f18;margin:10px 0;overflow:hidden;}.lg-progress-track span{height:100%;display:block;background:linear-gradient(90deg,#D7B38C,#bb8396);border-radius:10px;}
.lg-step{display:flex;gap:8px;font-size:10px;align-items:center;padding:9px 0;border-bottom:1px solid #3e2f4f0a;}.lg-step i{width:18px;height:18px;border-radius:50%;background:#a8ddb5;color:#3e2f4f;display:flex;align-items:center;justify-content:center;font-style:normal;}.lg-step.pending i{background:#dccff0;}
.lg-hero-badge{margin-top:18px;}.lg-hero .lg-pill{background:#fff8;color:#30243C;}
.lg-chart-title{font:800 14px 'Nunito Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#30243C;display:flex;align-items:center;gap:7px;}.lg-chart-title svg{width:18px;height:18px;color:#9563C4;}
.lg-empty{min-height:150px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#756383;font-size:12px;padding:12px;}.lg-empty strong{font-size:13px;margin-bottom:8px;}
.lg-health{font-size:10px;display:flex;justify-content:space-between;gap:6px;padding:5px 0;border-bottom:1px solid #3e2f4f0a;}.lg-health b{max-width:65%;text-align:right;overflow-wrap:anywhere;}
.lg-footer{font-size:10px;color:#e6d9ea;text-align:center;padding-top:10px;}
.lg-mode-banner{font-size:11px;color:#fff;background:#dccff01f;border:1px solid #dccff033;border-radius:12px;padding:6px 10px;}
[class*="st-key-lg_card"],[class*="st-key-lg_chart"],.st-key-lg_trade,.st-key-lg_settings,.st-key-lg_filters{background:linear-gradient(140deg,#FAF7FC,#fcf1ee);border:1px solid #ffffff99;border-radius:24px;padding:14px;box-shadow:0 6px 16px #24192f18;}
.st-key-lg_trade{background:linear-gradient(115deg,#F2E6D7,#DCCFF0,#F3C9DD);padding:9px 14px;}
.st-key-lg_header [data-testid="stHorizontalBlock"]{align-items:center;}
.st-key-lg_header .stButton button{background:transparent;border:0;color:white;font-size:11px;padding:7px 5px;min-height:32px;white-space:nowrap;}
.st-key-lg_header .stButton button[kind="primary"]{background:#F2E6D7;color:#30243C;border-radius:999px;}
.st-key-lg_navrail{padding-top:5px;}.st-key-lg_navrail .stButton button{background:transparent;border:0;color:#E6D9EA;border-radius:17px;min-height:49px;padding:10px 5px;}
.st-key-lg_navrail .stButton button[kind="primary"]{background:linear-gradient(135deg,#bdafd1,#9563c4);color:white;box-shadow:0 8px 14px #24192f55;}
.stMainBlockContainer .stButton button,.stMainBlockContainer .stDownloadButton button{font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:12px;border-radius:14px;}
[class*="st-key-lg_card"] .stButton button{background:linear-gradient(115deg,#faf7fc,#e6d5f0);border:1px solid #dccff0;color:#3e2f4f;border-radius:999px;}
.stMainBlockContainer .stButton button[kind="primary"]{background:#9563c4;border-color:#9563c4;color:white;}
.stMainBlockContainer label,.stMainBlockContainer [data-testid="stMarkdownContainer"]{font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
.stMainBlockContainer [data-testid="stWidgetLabel"] p{font-size:11px;}
.stMainBlockContainer [data-baseweb="select"] > div,.stMainBlockContainer [data-baseweb="input"]{border-radius:12px;background:#FAF7FC;color:#30243C;}
.stMainBlockContainer .stSegmentedControl button{font-size:10px;}
.st-key-lg_trade [data-testid="stMetricValue"]{font-size:17px;font-weight:800;}.st-key-lg_trade [data-testid="stMetricLabel"]{font-size:10px;}
.st-key-lg_mode .stSegmentedControl{margin-top:0;}.stMainBlockContainer [data-testid="stExpander"]{border:1px solid #dccff030;border-radius:12px;background:#FAF7FC;}
.stMainBlockContainer [data-testid="stPopover"] > button{min-height:20px;height:20px;padding:0;border:0;background:transparent;font-size:12px;}
.stMainBlockContainer [data-testid="stPopover"] > button > svg{display:none;}
.st-key-lg_header .stButton button[kind="primary"]{background:#F2E6D7;border-color:#F2E6D7;color:#30243C;}
.st-key-lg_navrail .stButton button[kind="primary"]{background:linear-gradient(135deg,#BDAFD1,#9563C4);border:0;}
.stMainBlockContainer{font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;height:auto!important;}
.stMainBlockContainer [data-testid="stPopoverButton"]{min-height:20px;height:20px;padding:0 3px;border:0;background:transparent;font-size:12px;}
.stMainBlockContainer [data-testid="stPopoverButton"] [data-testid="stIconMaterial"]{display:none;}
.st-key-lg_filters [data-testid="stExpander"]{border:0;}
.lg-nav-text{color:#fff;font-size:13px;}
.stMainBlockContainer [data-testid="stVerticalBlock"]{gap:10px;}
.st-key-lg_mobile_nav{display:none;}
@media(max-width:1100px){.stMainBlockContainer{margin:8px auto;padding:14px;border-radius:24px;}.lg-brand{font-size:16px;}.lg-kpi-value{font-size:21px;}.lg-hero h1{font-size:28px;}}
@media(min-width:761px) and (max-width:1100px){
 .stMainBlockContainer [data-testid="stHorizontalBlock"]:has(> [data-testid="stColumn"] > [data-testid="stVerticalBlock"] > [data-testid="stLayoutWrapper"] > .st-key-lg_card_quick){display:block;}
 .stMainBlockContainer [data-testid="stHorizontalBlock"]:has(> [data-testid="stColumn"] > [data-testid="stVerticalBlock"] > [data-testid="stLayoutWrapper"] > .st-key-lg_card_quick) > [data-testid="stColumn"]{width:100%;flex:1 1 100%;}
}
@media(max-width:760px){.stMainBlockContainer{margin:0;padding:12px;border-radius:0;}.lg-greeting{display:none;}.lg-hero{height:430px;padding:20px;}.lg-hero-copy{width:65%;}.lg-mascot{width:55%;left:46%;height:65%;bottom:20%;}.lg-progress{top:auto;bottom:12px;width:90%;right:5%;padding:10px;}.lg-step{display:inline-flex;width:48%;padding:5px 0;}.lg-hero h1{font-size:30px;}.lg-kpi{min-height:90px;}.lg-kpi-value{font-size:24px;}.st-key-lg_navrail [data-testid="stVerticalBlock"]{display:flex;flex-direction:row;flex-wrap:wrap;}.st-key-lg_navrail .stButton{display:inline-block;}.lg-brand{font-size:20px;}}
@media(max-width:760px){.st-key-lg_header [data-testid="stColumn"]:nth-child(n+2){display:none;}.st-key-lg_mobile_nav{display:block;}.st-key-lg_navrail{display:none;}.st-key-lg_kpis [data-testid="stHorizontalBlock"]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;}.st-key-lg_kpis [data-testid="stColumn"]{width:100%;min-width:0;}.lg-progress .lg-step{font-size:10px;}.lg-hero p{font-size:12px;}}
@media(max-width:760px){
 .stMainBlockContainer [data-testid="stHorizontalBlock"]{display:block;}
 .stMainBlockContainer [data-testid="stColumn"]{width:100%!important;flex:1 1 100%!important;min-width:0!important;}
 .stMainBlockContainer [data-testid="stColumn"]:has(.st-key-lg_navrail){display:none;}
 .st-key-lg_kpis [data-testid="stHorizontalBlock"]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));}
 [class*="st-key-lg_chart"] [data-testid="stHorizontalBlock"]{display:flex;flex-direction:row;}
 [class*="st-key-lg_chart"] [data-testid="stColumn"]:first-child{flex:8!important;}
 [class*="st-key-lg_chart"] [data-testid="stColumn"]:last-child{flex:1!important;}
}
"""


def inject(st, density="Thoải mái"):
    root = Path(__file__).resolve().parents[2]
    tokens = (root / "docs/ui_reference/design_tokens.css").read_text()
    st.markdown(f"<style>{tokens}\n{CSS}</style>", unsafe_allow_html=True)
    if density == "Gọn":
        st.markdown("<style>.stMainBlockContainer [data-testid='stVerticalBlock']{gap:6px}.lg-kpi{padding:8px;min-height:88px}</style>",unsafe_allow_html=True)
